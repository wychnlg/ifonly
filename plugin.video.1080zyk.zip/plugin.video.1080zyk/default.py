import sys
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs  # <--- 添加这一行

# --- 配置部分 ---
API_BASE = "https://api.yzzy-api.com/inc/api_mac10.php"
_HANDLE = int(sys.argv[1])
_URL = sys.argv[0]

def log(msg):
    xbmc.log(f"[YZZY-DEBUG] {msg}", xbmc.LOGINFO)

def get_url(**kwargs):
    return '{}?{}'.format(_URL, urllib.parse.urlencode(kwargs))

def make_request(params):
    """发送 HTTP 请求并解析 JSON"""
    params['out'] = 'json'
    query_string = urllib.parse.urlencode(params)
    url = f"{API_BASE}?{query_string}"
    log(f"Requesting URL: {url}")
    
    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            data = response.read()
            # 自动处理编码
            for encoding in ['utf-8', 'gbk', 'iso-8859-1']:
                try:
                    return json.loads(data.decode(encoding))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
            return None
    except Exception as e:
        log(f"Network Error: {e}")
        return None

def list_categories():
    """首页渲染"""
    # 搜索入口：显式传递 mode='listing' 并带上 is_search 标记
    search_item = xbmcgui.ListItem(label='[COLOR yellow]🔍 点击开始搜索视频[/COLOR]')
    url_search = get_url(mode='listing', is_search='true')
    xbmcplugin.addDirectoryItem(_HANDLE, url_search, search_item, isFolder=True)

    data = make_request({'ac': 'list'})
    if data and 'class' in data:
        for cat in data['class']:
            list_item = xbmcgui.ListItem(label=cat['type_name'])
            url = get_url(mode='listing', tid=cat['type_id'], pg=1)
            xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, isFolder=True)
    
    xbmcplugin.endOfDirectory(_HANDLE)

def list_videos(tid=None, page=1, keyword=None, is_search=False):
    """视频列表渲染 - 修复图片显示问题"""
    
    if is_search:
        keyboard = xbmc.Keyboard('', '请输入视频名称')
        keyboard.doModal()
        if keyboard.isConfirmed():
            keyword = keyboard.getText()
        if not keyword:
            xbmc.executebuiltin("Action(ParentDir)")
            return

    # 1. 先用 ac=list 获取视频 ID 列表
    params = {'ac': 'list', 'pg': page}
    if keyword:
        params['wd'] = keyword
    elif tid:
        params['t'] = tid
    else:
        xbmcplugin.endOfDirectory(_HANDLE)
        return

    data = make_request(params)
    if not data or not isinstance(data, dict) or not data.get('list'):
        xbmcgui.Dialog().notification('提示', '未找到相关内容', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(_HANDLE)
        return

    # 2. 【核心修复】获取当前页所有 ID，通过 ac=detail 批量补全图片和信息
    video_ids = [str(v['vod_id']) for v in data['list']]
    ids_str = ",".join(video_ids)
    
    detail_data = make_request({'ac': 'detail', 'ids': ids_str})
    
    # 如果详情请求失败，回退使用列表数据（虽然可能没图）
    display_list = detail_data.get('list', []) if detail_data else data['list']

    xbmcplugin.setContent(_HANDLE, 'movies')

    for video in display_list:
        title = video.get('vod_name', '未知')
        # 此时 ac=detail 会返回完整的 vod_pic
        thumb = video.get('vod_pic', '') 
        vod_id = video.get('vod_id')
        plot = video.get('vod_content', '无简介')
        
        # 修复某些相对路径图片问题
        if thumb and thumb.startswith('//'):
            thumb = 'https:' + thumb

        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb, 'fanart': thumb})
        list_item.setInfo('video', {
            'title': title, 
            'plot': plot,
            'genre': video.get('type_name', ''),
            'year': video.get('vod_year', ''),
            'director': video.get('vod_director', ''),
            'cast': video.get('vod_actor', '').split(',')
        })
        
        # 跳转到选集页
        url = get_url(mode='episodes', vod_id=vod_id, title=title, thumb=thumb)
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, isFolder=True)

    # 分页逻辑
    try:
            total_pages = int(data.get('pagecount', 1))
            current_page = int(data.get('page', 1))
            
            if current_page < total_pages:
                next_page = current_page + 1
                
                # 构建下一页的参数
                page_params = {
                    'mode': 'listing',
                    'pg': next_page
                }
                
                # 如果当前是搜索状态，带上关键词和搜索标记
                if keyword:
                    page_params['keyword'] = keyword
                    # 关键：下一页不需要再次弹窗，所以这里传 false 或者不传 is_search
                    # 但我们需要确保路由能识别这是搜索结果的翻页
                    page_params['is_search'] = 'false' 
                
                # 如果当前是分类状态，带上分类 ID
                if tid:
                    page_params['tid'] = tid
                
                url = get_url(**page_params)
                
                next_item = xbmcgui.ListItem(label=f"[COLOR orange]>> 下一页 ({next_page}/{total_pages}) >>[/COLOR]")
                xbmcplugin.addDirectoryItem(_HANDLE, url, next_item, isFolder=True)
    except Exception as e:
            log(f"分页构建出错: {e}")

    xbmcplugin.endOfDirectory(_HANDLE)

def list_episodes(vod_id, title, thumb):
    """点击视频后，根据 vod_id 获取播放详情"""
    
    # 再次请求 API，获取包含 vod_play_url 的详细数据
    detail_params = {
        'ac': 'detail',
        'ids': vod_id
    }
    data = make_request(detail_params)
    
    if not data or 'list' not in data or len(data['list']) == 0:
        xbmcgui.Dialog().notification('错误', '无法获取播放详情', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_HANDLE)
        return

    video_detail = data['list'][0]
    play_data = video_detail.get('vod_play_url', '')
    
    # 后续解析逻辑保持不变...
    sources = play_data.split('$$$')
    target_source = sources[0]
    for s in sources:
        if 'm3u8' in s.lower():
            target_source = s
            break
            
    episodes = target_source.split('#')
    for ep in episodes:
        if '$' in ep:
            parts = ep.split('$')
            ep_name, ep_url = parts[0], parts[1]
        else:
            ep_name, ep_url = title, ep

        if not ep_url.startswith('http'): continue

        list_item = xbmcgui.ListItem(label=ep_name)
        list_item.setArt({'thumb': thumb, 'icon': thumb})
        list_item.setInfo('video', {'title': ep_name})
        list_item.setProperty('IsPlayable', 'true')
        
        url = get_url(mode='play', url=ep_url)
        xbmcplugin.addDirectoryItem(_HANDLE, url, list_item, isFolder=False)
        
    xbmcplugin.endOfDirectory(_HANDLE)

import os
import base64

def play_video(url):
    """
    稳健版净化函数 - 修复 translatePath 报错
    """
    original_url = url
    
    # 兼容性处理：根据 Kodi 版本选择正确的 translatePath
    try:
        translated_path = xbmcvfs.translatePath("special://temp")
    except AttributeError:
        translated_path = xbmc.translatePath("special://temp")
        
    tmp_path = os.path.join(translated_path, "cleaned_play.m3u8")
    
    if '.m3u8' in url.lower():
        try:
            log(f"开始净化并写入临时文件: {url}")
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            
            with urllib.request.urlopen(req, timeout=5) as response:
                content = response.read().decode('utf-8')
            
            # 1. 自动处理二级索引
            if "#EXT-X-STREAM-INF" in content:
                lines = content.splitlines()
                for line in lines:
                    if line.strip() and not line.startswith("#"):
                        real_url = urllib.parse.urljoin(url, line.strip())
                        return play_video(real_url)

            # 2. 执行净化逻辑
            lines = content.splitlines()
            cleaned_m3u8 = []
            ad_keywords = ['ad.', 'ads', '/ad/', 'guanggao', '/gg/', 'xtm', 'byteimg']
            
            i = 0
            while i < len(lines):
                line = lines[i].strip()
                if line.startswith("#EXTINF:"):
                    try:
                        duration = float(line.split(":")[1].split(",")[0])
                        next_line = lines[i+1].strip() if (i+1) < len(lines) else ""
                        
                        is_ad = False
                        # 1. 只有时长极短（通常是1-2秒的占位符）才直接拦截
                        if duration < 2.1:
                            is_ad = True
                        
                        # 2. 只有包含特定广告域名的才拦截 (针对 17 秒广告)
                        # 这种广告通常来自类似 *.byteimg.com, *.volces.com 或混入的杂乱域名
                        ad_domains = ['byteimg', 'volces', 'pstatp', 'toutiao', 'p1-ad', 'p3-ad']
                        if any(domain in next_line.lower() for domain in ad_domains):
                            is_ad = True
                        
                        # 3. 针对非凡资源(yzzy)的特定逻辑：
                        # 它的正片切片通常是 index0.ts, index1.ts 或规则的 hex 字符
                        # 如果 URL 包含明显的广告插件特征才拦截
                        if "/ad/" in next_line or "/gg/" in next_line:
                            is_ad = True

                        if is_ad:
                            log(f"精准拦截广告: {duration}s -> {next_line[:40]}")
                            i += 2
                            continue
                    except:
                        pass
                
                if line and not line.startswith("#"):
                    line = urllib.parse.urljoin(url, line)
                cleaned_m3u8.append(line)
                i += 1

            # 3. 写入临时文件
            with open(tmp_path, "w", encoding="utf-8") as f:
                f.write("\n".join(cleaned_m3u8))
            
            # 使用临时文件路径进行播放
            url = tmp_path
            log(f"净化完成，临时文件位于: {url}")
            
        except Exception as e:
            log(f"净化失败，回退到原始地址: {e}")
            url = original_url

    # 构建播放项
    play_item = xbmcgui.ListItem(path=url)
    # 如果是本地文件，需要手动设置内容类型
    if url == tmp_path:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.manifest_type', 'hls') # 明确告知是 HLS
        play_item.setMimeType('application/vnd.apple.mpegurl')
        play_item.setContentLookup(False) # 告诉 Kodi 不要去网上搜这个文件的信息

    xbmcplugin.setResolvedUrl(_HANDLE, True, listitem=play_item)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode', 'home')
    
    if mode == 'home':
        list_categories()
    elif mode == 'listing':
        # 只有当 is_search 为 true 且没有 keyword 时，才认为是“发起新搜索”
        is_search_trigger = params.get('is_search') == 'true'
        keyword = params.get('keyword')
        
        # 如果已经有关键词了，说明是翻页，不应该再弹窗
        if keyword:
            is_search_trigger = False
            
        list_videos(
            tid=params.get('tid'), 
            page=params.get('pg', 1), 
            keyword=keyword,
            is_search=is_search_trigger
        )

    elif mode == 'episodes':
        list_episodes(params.get('vod_id'), params.get('title'), params.get('thumb'))
    elif mode == 'play':
        play_video(params.get('url'))

if __name__ == '__main__':
    router(sys.argv[2][1:])